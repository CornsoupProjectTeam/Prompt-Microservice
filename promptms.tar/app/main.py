from application.prompt_service import PersChatService

if __name__ == "__main__":
    chat_service = PersChatService()
    print(f"챗봇: {chat_service.start_message}")

    for i in range(10):
        user_input = input(f"사용자: ")
        reply = chat_service.generate_response(user_input)
        print(f"챗봇: {reply}")

    print("\n[시스템] 총 10번의 대화를 마쳤어요. 대화 종료합니다. 좋은 하루 보내세요!")
