# Prompt-Microservice


이 프로젝트는 한국어 특화 Gemma2 모델을 활용해 Big5 성향을 유도하도록 정의된 프롬프트를 기반으로 사용자와의 실시간 대화를 Kafka를 통해 전송하는 Prompt 마이크로서비스입니다.
